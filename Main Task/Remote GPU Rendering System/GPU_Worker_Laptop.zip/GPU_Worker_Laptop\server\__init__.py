"""Remote GPU worker daemon."""
